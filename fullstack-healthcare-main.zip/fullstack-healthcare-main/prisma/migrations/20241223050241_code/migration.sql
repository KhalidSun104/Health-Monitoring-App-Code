-- AlterTable
ALTER TABLE "Doctor" ADD COLUMN     "colorCode" TEXT;

-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "colorCode" TEXT;

-- AlterTable
ALTER TABLE "Staff" ADD COLUMN     "colorCode" TEXT;
