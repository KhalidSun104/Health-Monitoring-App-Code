export interface SearchParamsProps {
  searchParams?: Promise<{ [key: string]: string | undefined }>;
}
